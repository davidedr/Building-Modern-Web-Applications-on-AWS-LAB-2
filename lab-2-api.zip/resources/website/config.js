var G_API_GW_URL_STR = null;
var G_COGNITO_HOSTED_URL_STR = null;